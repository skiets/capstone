<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>QR CodeIn</title>
        <link rel="stylesheet" type="text/css" href="css/style_generateqr.css">
        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">      
    </head>
    <body>

        <!--main content-->
        <div class="details">
            <div class="Insertinformation">
                <div class="cardheader">
                    <h2>Student Form</h2>
                    <a href="#" class="btn">Confirm</a>
                </div>  
                <div class="form">
                    <input type="text" name="fullname" autocomplete="off" required>
                        <label for="fullname">
                            <span class="content-name">Full name & ID number</span>
                        </label>
                        <input type="text" name="section" autocomplete="off" required>
                    <label for="section">
                        <span class="content-name">Year & Section</span>
                    </label>
                </div>                    
            </div>
            <div class="recentadmin">
                <div class="cardheader">
                    <h2>Here's your QR code</h2>
                </div>
            </div>
        </div>
                
                
        <!--main content-->


   

    
    </body>
</html>