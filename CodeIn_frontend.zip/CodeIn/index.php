<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>QR CodeIn</title>
        <link rel="stylesheet" type="text/css" href="css/style_index.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">      
    </head>
    <body>
        
        <script src="javascript/script_main.js"></script>
        <script src="javascript/ajax_script.js"></script>
        <div class="container">
            <div class="navi" id="navi" >
                <ul>
                    <li>
                        <a href="#" data-target="main">
                            <span class="icon"><img src="img/logo1.png" alt=""></span>
                            <span class="title"><h2>QR CodeIn</h2></span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="active" data-target="main">
                            <span class="icon"><i class="las la-laptop-code"></i></span>
                            <span class="title">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" data-target="generate_qr">
                            <span class="icon"><i class="las la-qrcode"></i></span>
                            <span class="title">Generate QR Code</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon"><i class="las la-address-book"></i></span>
                            <span class="title">Student List</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon"><i class="las la-chart-bar"></i></span>
                            <span class="title">Analysis</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon"><i class="las la-user-cog"></i></span>
                            <span class="title">Profile Settings</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon"><i class="las la-question-circle"></i></span>
                            <span class="title">Help</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon"><i class="las la-info-circle"></i></span>
                            <span class="title">About Us</span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon"><i class="las la-sign-out-alt"></i></span>
                            <span class="title">Sign Out</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!--sidebar-->

            <!--topbar--->
            <div class="main" >
                <div class="topbar">
                    <div class="toggle" onclick="toggleMenu();"></div>
                    <div class="user">
                        <img src="img/adminsample.png" alt="">
                    </div>
                </div>
                <!--topbar--->

                 <!--Main--->
                <div id="content">

                    <?php include('main.php'); ?>
                </div>


            </div>
        </div>

       
      
        
    </body>
</html>