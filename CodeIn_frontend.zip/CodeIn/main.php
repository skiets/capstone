<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>QR CodeIn</title>
        <link rel="stylesheet" type="text/css" href="css/style_main.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">      
    </head>
    <body>

                <div class="cardbox" id="content"> 
                    <div class="card">
                        <div>
                            <div class="number">1,325</div>
                            <div class="cardname">Student Listed</div>
                        </div>
                        <div class="iconbox">
                            <i class="las la-clipboard-list"></i>
                        </div>
                    </div>
                    <div class="card">
                        <div>
                            <div class="number">6</div>
                            <div class="cardname">Admin Listed</div>
                        </div>
                        <div class="iconbox">
                            <i class="las la-users-cog"></i>
                        </div>
                    </div>
                    <div class="card">
                        <div>
                            <div class="number">683</div>
                            <div class="cardname">Generated Certificate</div>
                        </div>
                        <div class="iconbox">
                            <i class="las la-certificate"></i>
                        </div>
                    </div>
                </div>
                
                <div class="details">
                    <div class="recentadded">
                        <div class="cardheader">
                            <h2>Recently Student Added</h2>
                            <a href="#" class="btn">View All</a>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <td>Full Name</td>
                                    <td>Year</td>
                                    <td>Section</td>
                                    <td>Date</td>
                                    <td>Time</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                                <tr>
                                    <td>John Rey M Dalit</td>
                                    <td>4th</td>
                                    <td>1st</td>
                                    <td>10/11/2021</td>
                                    <td>2:40pm</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="recentadmin">
                        <div class="cardheader">
                            <h2>Calendar Event</h2>
                        </div>
                    </div>
                </div>

                <!--main content-->



      
        
    </body>
</html>