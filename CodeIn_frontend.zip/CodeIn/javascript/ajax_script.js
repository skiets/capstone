$(document).ready(function(){

   var trigger = $('#navi ul li a'),
    con = $('#content')


trigger.on('click', function(){

    var $this = $(this)
    target = $this.data('target')

    con.load(target + '.php')

    return false
    });
});