function toggleMenu(){
    let toggle = document.querySelector('.toggle')
    let navi = document.querySelector('.navi')
    let main = document.querySelector('.main')
    toggle.classList.toggle('active')
    navi.classList.toggle('active')
    main.classList.toggle('active')
}



